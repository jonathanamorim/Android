package com.example.gustavoleitao.acessowebrest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {


    private Button gotoMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gotoMap = (Button) findViewById(R.id.btOnibus);
    }

    @Override
    protected void onStart() {
        super.onStart();

    }

    public void onClickButton(View view){
        Intent intent = new Intent(this, MapsActivity.class);
        startActivity(intent);
    }

}
