package imd.ufrn.br.fragmenttest;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends FragmentActivity {

    int i = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);

        if (savedInstanceState == null) {
            getFragmentManager().beginTransaction()
                    .add(R.id.fragment_container, new TelaFragment())
                    .commit();
        }

        Button b = (Button) findViewById(R.id.button);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (i == 0) {
                    getFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, new TelaFragment())
                            .commit();
                    i = 1;
                } else {
                    getFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, new TelaFragment2())
                            .commit();
                    i = 0;
                }
            }
        });
    }
}
